
Ase files are aseprite files, made by using aseprite software.

While you're importing the assets into your game engine you can simply use png files. 

<3 thank you! Feel free to use my assets in your game projects! You can contact me if you have any suggestions about asset creation.
